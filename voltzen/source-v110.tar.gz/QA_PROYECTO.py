"""Comprobaciones estáticas sin Android SDK: python QA_PROYECTO.py"""
from pathlib import Path
from xml.etree import ElementTree
import math
p = Path(__file__).parent
files = [
    'settings.gradle', 'build.gradle', 'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/glc/voltzen/MainActivity.java',
    'app/src/main/java/com/glc/voltzen/RideService.java',
    'app/src/main/java/com/glc/voltzen/Store.java',
    'app/src/main/java/com/glc/voltzen/SpeedometerView.java',
    'COMPILAR_WIN11.bat', 'README_ES.md',
]
for file in files:
    assert (p / file).is_file(), file
for xml in p.rglob('*.xml'):
    ElementTree.parse(xml)
manifest = (p/'app/src/main/AndroidManifest.xml').read_text()
assert 'foregroundServiceType="location"' in manifest
assert 'FOREGROUND_SERVICE_LOCATION' in manifest
assert 'android:allowBackup="false"' in manifest
service = (p/'app/src/main/java/com/glc/voltzen/RideService.java').read_text()
assert 'onLocationChanged' in service and 'distanceTo' in service
assert 'state.distanceM+=displacement' in service
assert 'Pico GPS descartado' in service
store = (p/'app/src/main/java/com/glc/voltzen/Store.java').read_text()
assert 'v1*ah1+(batteryCount==2?battery2Wh():0)' in store
assert 'learningRatio' in store and 'distanceMiles<2.0' in store
assert math.isclose(48*20*2,1920)
print('OK: archivos, XML, permisos y reglas clave. La compilacion final requiere Android SDK.')
