package com.glc.voltzen;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONObject;

/** Service GPS foreground; no precisa conexión a Internet ni BMS. */
public class RideService extends Service implements LocationListener {
    public static final String START="com.glc.voltzen.START",STOP="com.glc.voltzen.STOP";
    public static volatile RideService live;
    public static final String CHANNEL="voltzen_ride";
    public static class Snapshot {
        public long startEpoch, startElapsed, movingMs;
        public double distanceM,maxSpeedMps,speedMps,accuracy=999,uphillM,estimatedWh,start1=100,start2=100;
        public long lastFixElapsed=0;
        public int accepted=0,rejected=0;
        public String configJson="{}",status="Buscando GPS";
        public boolean gpsAvailable=true;
        public long elapsed(){return Math.max(0,SystemClock.elapsedRealtime()-startElapsed);}
        public double miles(){return distanceM/1609.344;}
        public double km(){return distanceM/1000;}
        public Store.Config rideConfig(){try{return Store.Config.fromJson(new JSONObject(configJson));}catch(Exception ex){return new Store.Config();}}
        public JSONObject toJson(){JSONObject j=new JSONObject();try{
            j.put("startEpoch",startEpoch);j.put("movingMs",movingMs);j.put("distanceM",distanceM);
            j.put("maxSpeedMps",maxSpeedMps);j.put("estimatedWh",estimatedWh);j.put("start1",start1);j.put("start2",start2);
            j.put("accuracy",accuracy);j.put("uphillM",uphillM);j.put("accepted",accepted);j.put("rejected",rejected);
            j.put("configJson",configJson);
        }catch(Exception ignored){}return j;}
        public static Snapshot fromJson(JSONObject j){Snapshot x=new Snapshot();
            x.startEpoch=j.optLong("startEpoch",System.currentTimeMillis());
            x.startElapsed=SystemClock.elapsedRealtime()-Math.max(0,System.currentTimeMillis()-x.startEpoch);
            x.movingMs=j.optLong("movingMs",0);x.distanceM=j.optDouble("distanceM",0);
            x.maxSpeedMps=j.optDouble("maxSpeedMps",0);x.estimatedWh=j.optDouble("estimatedWh",0);x.start1=j.optDouble("start1",100);x.start2=j.optDouble("start2",100);
            x.accuracy=j.optDouble("accuracy",999);x.uphillM=j.optDouble("uphillM",0);
            x.accepted=j.optInt("accepted",0);x.rejected=j.optInt("rejected",0);
            x.configJson=j.optString("configJson","{}");return x;
        }
    }
    public final Snapshot state=new Snapshot();
    private LocationManager manager;
    private Location lastPoint;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private long lastSave=0,lastNotification=0;
    private int stoppedSamples=0,spikeSamples=0;
    private boolean tracking=false;
    private final Runnable ticker=new Runnable(){@Override public void run(){
        if(!tracking)return;
        long age=state.lastFixElapsed==0?999999:SystemClock.elapsedRealtime()-state.lastFixElapsed;
        if(age>5500){state.speedMps=0;state.status="Esperando señal GPS";}
        if(SystemClock.elapsedRealtime()-lastSave>5000)persist();
        if(SystemClock.elapsedRealtime()-lastNotification>12000)notifyRefresh();
        handler.postDelayed(this,1000);
    }};
    @Override public void onCreate(){super.onCreate();live=this;manager=(LocationManager)getSystemService(LOCATION_SERVICE);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Trayecto activo VoltZen",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent i,int flags,int id){
        String action=i==null?START:i.getAction();
        if(STOP.equals(action)){finish(i);return START_NOT_STICKY;}
        if(tracking)return START_STICKY;
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            stopSelf();return START_NOT_STICKY;
        }
        String raw=Store.prefs(this).getString("ride_current",null);
        if(Store.prefs(this).getBoolean("ride_active",false)&&raw!=null){
            try{Snapshot old=Snapshot.fromJson(new JSONObject(raw));
                state.startEpoch=old.startEpoch;state.startElapsed=old.startElapsed;state.movingMs=old.movingMs;
                state.distanceM=old.distanceM;state.maxSpeedMps=old.maxSpeedMps;state.estimatedWh=old.estimatedWh;
                state.start1=old.start1;state.start2=old.start2;state.uphillM=old.uphillM;
                state.configJson=old.configJson;state.accepted=old.accepted;state.rejected=old.rejected;
            }catch(Exception e){initialise(i);}
        }else initialise(i);
        tracking=true;state.status="Buscando GPS";
        try{
            if(Build.VERSION.SDK_INT>=29)startForeground(8124,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
            else startForeground(8124,notification());
        }catch(Exception e){tracking=false;stopSelf();return START_NOT_STICKY;}
        startLocation();handler.removeCallbacks(ticker);handler.post(ticker);persist();return START_STICKY;
    }
    private void initialise(Intent i){
        Store.Config c=Store.config(this);
        state.startEpoch=System.currentTimeMillis();state.startElapsed=SystemClock.elapsedRealtime();
        state.movingMs=0;state.distanceM=0;state.maxSpeedMps=0;state.uphillM=0;state.estimatedWh=0;
        state.start1=i==null?c.start1:i.getDoubleExtra("start1",c.start1);
        state.start2=i==null?c.start2:i.getDoubleExtra("start2",c.start2);
        state.configJson=c.toJson().toString();
    }
    private void startLocation(){
        try{manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0,this,Looper.getMainLooper());}
        catch(SecurityException|IllegalArgumentException ignored){}
        try{manager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,1500,0,this,Looper.getMainLooper());}
        catch(SecurityException|IllegalArgumentException ignored){}
        try{state.gpsAvailable=manager.isProviderEnabled(LocationManager.GPS_PROVIDER);}catch(Exception ignored){state.gpsAvailable=false;}
        if(!state.gpsAvailable)state.status="GPS desactivado";
    }
    @Override public void onLocationChanged(Location l){
        if(!tracking)return;
        Store.Config cfg=state.rideConfig();
        // No mezclar GPS y NETWORK en la misma ruta: causaría saltos entre proveedores.
        try {if(manager.isProviderEnabled(LocationManager.GPS_PROVIDER) && !LocationManager.GPS_PROVIDER.equals(l.getProvider()))return;}catch(Exception ignored){}
        if(!l.hasAccuracy()||l.getAccuracy()>cfg.gpsAccuracy||l.getAccuracy()<=0){state.rejected++;return;}
        long now=SystemClock.elapsedRealtime();
        long fixAge=(SystemClock.elapsedRealtimeNanos()-l.getElapsedRealtimeNanos())/1_000_000;
        if(fixAge>4500||fixAge< -1000){state.rejected++;return;}
        state.lastFixElapsed=now;state.accuracy=l.getAccuracy();
        if(lastPoint==null){lastPoint=new Location(l);state.status="GPS conectado";return;}
        double dt=(l.getElapsedRealtimeNanos()-lastPoint.getElapsedRealtimeNanos())/1e9;
        if(dt<=0.35){return;}
        if(dt>22){lastPoint=new Location(l);state.speedMps=0;state.status="Señal recuperada";return;}
        double displacement=lastPoint.distanceTo(l);
        double geometricSpeed=displacement/dt;
        double measured=l.hasSpeed()?l.getSpeed():geometricSpeed;
        if(l.hasSpeed()&&Build.VERSION.SDK_INT>=26&&l.hasSpeedAccuracy()&&l.getSpeedAccuracyMetersPerSecond()>3.5)
            measured=geometricSpeed;
        if(measured>36||geometricSpeed>38||(l.hasSpeed()&&geometricSpeed>measured+8&&displacement>12)){
            state.rejected++;spikeSamples++;state.status="Pico GPS descartado";
            // Reanclar tras varios puntos imposibles para no quedar bloqueado en una coordenada antigua.
            if(spikeSamples>=3){lastPoint=new Location(l);spikeSamples=0;}
            return;
        }
        spikeSamples=0;
        double threshold=Math.max(2.8,Math.min(8.0,(l.getAccuracy()+lastPoint.getAccuracy())*.22));
        boolean actuallyMoving=measured>1.35&&geometricSpeed>0.85&&displacement>=threshold;
        if(actuallyMoving){
            state.distanceM+=displacement;
            state.estimatedWh+=(displacement/1609.344)*cfg.whPerMile(Math.max(3,measured*2.2369362921));
            state.movingMs+=(long)(dt*1000);
            state.speedMps=state.speedMps==0?measured:state.speedMps*.44+measured*.56;
            state.maxSpeedMps=Math.max(state.maxSpeedMps,state.speedMps);
            if(l.hasAltitude()&&lastPoint.hasAltitude()){
                boolean altReliable=(Build.VERSION.SDK_INT<26||!l.hasVerticalAccuracy()||l.getVerticalAccuracyMeters()<=12);
                double rise=l.getAltitude()-lastPoint.getAltitude();if(altReliable&&rise>=3&&rise<20)state.uphillM+=rise;
            }
            lastPoint=new Location(l);stoppedSamples=0;state.accepted++;state.status="En movimiento";
        }else{
            stoppedSamples++;
            if(stoppedSamples>=3){state.speedMps=0;state.status="Detenido · distancia pausada";}
            if(measured<1.15||displacement<3.0)lastPoint=new Location(l);
        }
        if(now-lastSave>5000)persist();
    }
    @Override public void onProviderDisabled(String provider){state.status="GPS desactivado";state.gpsAvailable=false;state.speedMps=0;}
    @Override public void onProviderEnabled(String provider){state.gpsAvailable=true;state.status="Buscando GPS";}
    @Override public void onStatusChanged(String provider,int status,Bundle extras){}
    private Notification notification(){
        Intent open=new Intent(this,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent p=PendingIntent.getActivity(this,91,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Store.Config c=state.rideConfig();
        String dis=c.mph?Store.fmt(state.miles(),1)+" mi":Store.fmt(state.km(),1)+" km";
        return new Notification.Builder(this,CHANNEL).setSmallIcon(com.glc.voltzen.R.drawable.ic_voltzen)
                .setContentTitle("VoltZen · seguimiento activo")
                .setContentText(dis+" · "+state.status).setContentIntent(p).setOngoing(true)
                .setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE).build();
    }
    private void notifyRefresh(){try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(8124,notification());}catch(Exception ignored){}
        lastNotification=SystemClock.elapsedRealtime();}
    private void persist(){if(!tracking)return;
        Store.prefs(this).edit().putBoolean("ride_active",true)
                .putString("ride_current",state.toJson().toString()).apply();lastSave=SystemClock.elapsedRealtime();}
    private void finish(Intent i){
        if(!tracking){String raw=Store.prefs(this).getString("ride_current",null);
            if(raw!=null)try{Snapshot restored=Snapshot.fromJson(new JSONObject(raw));
                state.startEpoch=restored.startEpoch;state.movingMs=restored.movingMs;state.distanceM=restored.distanceM;
                state.maxSpeedMps=restored.maxSpeedMps;state.estimatedWh=restored.estimatedWh;state.start1=restored.start1;state.start2=restored.start2;
                state.configJson=restored.configJson;state.uphillM=restored.uphillM;
                state.accepted=restored.accepted;state.rejected=restored.rejected;
            }catch(Exception ignored){}
        }
        tracking=false;handler.removeCallbacks(ticker);
        if(manager!=null)try{manager.removeUpdates(this);}catch(Exception ignored){}
        double end1=i==null?-1:i.getDoubleExtra("end1",-1);
        double end2=i==null?-1:i.getDoubleExtra("end2",-1);
        Store.Config atStart=state.rideConfig();
        boolean calibrated=Store.learn(this,atStart,state.miles(),state.movingMs,state.start1,state.start2,end1,end2);
        // Mantener los últimos porcentajes declarados como valores sugeridos para la próxima salida.
        Store.Config updated=Store.config(this);
        if(end1>=0&&end1<=100)updated.start1=end1;
        if(atStart.batteryCount==2&&end2>=0&&end2<=100)updated.start2=end2;
        Store.save(this,updated);
        JSONObject record=new JSONObject();try{
            record.put("date",state.startEpoch);record.put("end",System.currentTimeMillis());
            record.put("distanceMi",state.miles());record.put("movingMs",state.movingMs);
            record.put("durationMs",Math.max(0,System.currentTimeMillis()-state.startEpoch));
            record.put("maxMph",state.maxSpeedMps*2.2369362921);
            record.put("avgMph",state.movingMs>0?state.miles()/(state.movingMs/3_600_000.0):0);
            record.put("estimatedWh",state.estimatedWh);record.put("climbM",state.uphillM);
            record.put("start1",state.start1);record.put("start2",state.start2);
            record.put("end1",end1);record.put("end2",end2);
            record.put("calibrated",calibrated);record.put("config",atStart.toJson());
            record.put("accepted",state.accepted);record.put("rejected",state.rejected);
        }catch(Exception ignored){}
        if(state.startEpoch>0)Store.addTrip(this,record);
        Store.prefs(this).edit().putBoolean("ride_active",false).remove("ride_current").apply();
        stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
    }
    @Override public void onDestroy(){handler.removeCallbacks(ticker);
        if(manager!=null)try{manager.removeUpdates(this);}catch(Exception ignored){}
        tracking=false;live=null;super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
