package com.glc.voltzen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Indicador de autonomía relativa de la sesión, calculado, no lectura de BMS. */
public final class RangeBarView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int track=0xff263545,accent=0xff13e3ee;
    private float amount=1;
    public RangeBarView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setState(float value,Store.Config cfg){amount=Math.max(0,Math.min(1,value));
        track=Store.blend(cfg.bg(),cfg.fg(),cfg.dark?.13f:.16f);accent=cfg.cyan();invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),r=h*.5f;
        p.clearShadowLayer();p.setColor(track);p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(new RectF(0,0,w,h),r,r,p);
        if(amount>0){float v=Math.max(h*.25f,w*amount);p.setColor(accent);
            p.setShadowLayer(h*.7f,0,0,accent);
            c.drawRoundRect(new RectF(0,0,Math.min(w,v),h),r,r,p);p.clearShadowLayer();}
    }
}
