package com.glc.voltzen;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** VoltZen 1.2 — Interfaz nativa, sin anuncios, servicios de terceros ni Internet. */
public class MainActivity extends Activity {
    private static final int GPS_PERMISSION=120,NOTIFICATION_PERMISSION=121,EXPORT_CSV=122;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Store.Config cfg;
    private LinearLayout base,body,navigation;
    private int tab=0;
    private boolean focus=false,wide=false;
    private SpeedometerView meter;
    private TextView remainLabel,tripLabel,elapsedLabel,runLabel,signalLabel,modelLabel,tipLabel;
    private Button trackingButton;
    private RangeBarView rangeBar;
    private final Runnable update=new Runnable(){@Override public void run(){
        if(tab==0)refreshDashboard();handler.postDelayed(this,1000);
    }};

    @Override public void onCreate(Bundle state){super.onCreate(state);
        cfg=Store.config(this);
        focus=Store.prefs(this).getBoolean("focus_mode",false);
        if(state!=null)tab=state.getInt("selected_tab",0);
        if(focus)tab=0;
        applyOrientation();configureWindow();render();handler.post(update);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);
    }
    @Override protected void onSaveInstanceState(Bundle state){state.putInt("selected_tab",tab);super.onSaveInstanceState(state);}
    @Override public void onDestroy(){handler.removeCallbacks(update);super.onDestroy();}
    @Override public void onResume(){super.onResume();cfg=Store.config(this);configureWindow();
        // Si Android finalizó el servicio, recuperar la sesión al volver a abrir la app.
        if(Store.prefs(this).getBoolean("ride_active",false) && RideService.live==null &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED){
            try{Intent resume=new Intent(this,RideService.class);resume.setAction(RideService.START);startForegroundService(resume);}catch(Exception ignored){}
        }
        applyOrientation();if(base!=null)render();}
    private void applyOrientation(){
        int requested=cfg.orientationMode==1?ActivityInfo.SCREEN_ORIENTATION_PORTRAIT:
                cfg.orientationMode==2?ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_SENSOR;
        if(getRequestedOrientation()!=requested)setRequestedOrientation(requested);
    }
    private void setFocus(boolean value){
        focus=value;Store.prefs(this).edit().putBoolean("focus_mode",value).apply();
        if(focus)tab=0;render();
    }
    private void flipOrientation(){cfg.orientationMode=wide?1:2;Store.save(this,cfg);applyOrientation();render();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void configureWindow(){
        if(focus)getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(cfg.bg());getWindow().setNavigationBarColor(cfg.bg());
        int flag=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(cfg.dark?0:flag);
        if(cfg.keepAwake)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    private AlertDialog.Builder alert(){return new AlertDialog.Builder(this, cfg.dark ? android.R.style.Theme_Material_Dialog_Alert : android.R.style.Theme_Material_Light_Dialog_Alert);}
    private GradientDrawable bg(int color,int round){GradientDrawable d=new GradientDrawable();
        d.setColor(color);d.setCornerRadius(dp(round));return d;}
    private TextView text(String value,float size,int color,boolean strong){TextView v=new TextView(this);
        v.setText(value);v.setTextColor(color);v.setTextSize(size*cfg.textScale);
        v.setFontFeatureSettings("tnum");v.setGravity(Gravity.CENTER_VERTICAL);
        v.setTypeface(Typeface.create(strong?"sans-serif-medium":"sans-serif",strong?Typeface.BOLD:Typeface.NORMAL));return v;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout parent,int size){View v=new View(this);parent.addView(v,lp(1,size));}
    private void addMargin(LinearLayout l,View v,int top,int bottom){LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(top);p.bottomMargin=dp(bottom);l.addView(v,p);}
    private LinearLayout panel(){LinearLayout p=vertical();p.setPadding(dp(17),dp(17),dp(17),dp(17));p.setBackground(bg(cfg.panel(),19));return p;}
    private Button button(String label,boolean primary){Button b=new Button(this);
        b.setText(label);b.setTextColor(primary?cfg.bg():cfg.fg());b.setTextSize(14*cfg.textScale);
        b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setMinHeight(dp(53));b.setBackground(bg(primary?cfg.cyan():cfg.panel(),14));
        b.setPadding(dp(13),dp(9),dp(13),dp(9));return b;}
    private void heading(String title,String subtitle){TextView h=text(title,24,cfg.fg(),true);body.addView(h);
        if(subtitle!=null){TextView s=text(subtitle,13,cfg.muted(),false);addMargin(body,s,3,12);}else gap(body,13);
    }
    private TextView navItem(String label,int selected,boolean verticalMenu){
        TextView item=text(label,verticalMenu?11:10,selected==tab?cfg.cyan():cfg.muted(),true);
        item.setGravity(Gravity.CENTER);
        item.setMinHeight(dp(verticalMenu?56:49));
        if(selected==tab)item.setBackground(bg(cfg.panel(),12));
        item.setOnClickListener(v->{tab=selected;render();});
        return item;
    }
    private void render(){
        cfg=Store.config(this);wide=getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE;
        configureWindow();
        meter=null;remainLabel=null;tripLabel=null;elapsedLabel=null;runLabel=null;
        trackingButton=null;rangeBar=null;signalLabel=null;modelLabel=null;tipLabel=null;
        base=vertical();base.setBackgroundColor(cfg.bg());
        LinearLayout top=horizontal();
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(wide?19:18),dp(wide?9:12),dp(wide?16:14),dp(wide?8:10));
        LinearLayout title=vertical();title.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand=horizontal();brand.setGravity(Gravity.CENTER_VERTICAL);
        DashboardIcon logo=new DashboardIcon(this,DashboardIcon.BOLT,cfg.cyan());
        LinearLayout.LayoutParams logoParams=lp(wide?28:26,wide?30:29);
        logoParams.rightMargin=dp(7);brand.addView(logo,logoParams);
        TextView wordmark=text("VOLTZEN",wide?21:20,cfg.fg(),true);
        wordmark.setLetterSpacing(.035f);brand.addView(wordmark);
        title.addView(brand);
        TextView sub=text(focus?"FOCUS  ·  SOLO LO ESENCIAL":"E-BIKE  ·  SMART DASHBOARD",wide?9:8,cfg.muted(),true);
        sub.setLetterSpacing(.12f);title.addView(sub);
        top.addView(title,new LinearLayout.LayoutParams(0,dp(wide?54:57),1));
        if(tab==0){
            Button focusButton=button(focus?"⇥  SALIR FOCUS":"◉  FOCUS",false);
            focusButton.setMinHeight(dp(wide?42:39));
            focusButton.setTextSize((wide?11:10)*cfg.textScale);
            focusButton.setBackground(dashBackground(20));
            LinearLayout.LayoutParams fp=lp(focus?(wide?144:115):(wide?105:100),wide?43:40);fp.rightMargin=dp(6);
            top.addView(focusButton,fp);focusButton.setOnClickListener(v->setFocus(!focus));
        }
        if(!focus){
            Button rotate=button(wide?"▯":"▭",false);rotate.setContentDescription("Cambiar entre horizontal y vertical");
            rotate.setOnClickListener(v->flipOrientation());
            LinearLayout.LayoutParams rp=lp(wide?43:38,40);rp.rightMargin=dp(5);top.addView(rotate,rp);
            Button theme=button(cfg.dark?"☀":"☾",false);theme.setContentDescription("Cambiar tema");
            theme.setOnClickListener(v->{cfg.dark=!cfg.dark;Store.save(this,cfg);render();});top.addView(theme,lp(wide?43:38,40));
        }
        base.addView(top);
        View line=new View(this);line.setBackgroundColor(Store.blend(cfg.bg(),cfg.fg(),.12f));base.addView(line,lp(-1,1));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setVerticalScrollBarEnabled(false);
        body=vertical();body.setPadding(dp(wide?11:16),dp(wide?9:12),dp(wide?11:16),dp(12));scroll.addView(body);
        if(wide&&!focus){
            LinearLayout mid=horizontal();
            LinearLayout side=vertical();side.setPadding(dp(5),dp(13),dp(5),dp(8));
            String[] icons={"◉", "▤", "◷", "⚙"};
            String[] names={"TABLERO","MI BICI","VIAJES","AJUSTES"};
            for(int n=0;n<4;n++){
                TextView entry=navItem(icons[n]+"\n"+names[n],n,true);
                LinearLayout.LayoutParams sp=lp(-1,64);sp.bottomMargin=dp(7);side.addView(entry,sp);
            }
            mid.addView(side,lp(101,-1));
            View separator=new View(this);separator.setBackgroundColor(Store.blend(cfg.bg(),cfg.fg(),.12f));mid.addView(separator,lp(1,-1));
            mid.addView(scroll,new LinearLayout.LayoutParams(0,-1,1));
            base.addView(mid,new LinearLayout.LayoutParams(-1,0,1));
        }else{
            base.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        }
        if(tab==0)dashboard();else if(tab==1)bikeSettings();else if(tab==2)history();else settingsPage();
        if(!wide&&!focus){
            navigation=horizontal();navigation.setPadding(dp(7),dp(5),dp(7),dp(8));
            String[] names={"TABLERO","MI BICI","VIAJES","AJUSTES"};
            for(int n=0;n<4;n++){
                TextView entry=navItem(names[n],n,false);
                LinearLayout.LayoutParams itemLp=new LinearLayout.LayoutParams(0,dp(49),1);
                itemLp.leftMargin=dp(2);itemLp.rightMargin=dp(2);
                navigation.addView(entry,itemLp);
            }
            base.addView(navigation);
        }
        setContentView(base);if(tab==0)refreshDashboard();
    }
    /** Paneles suaves, con ligero degradado, como la referencia. Respeta colores configurables. */
    private GradientDrawable dashBackground(int radius){
        int a=Store.blend(cfg.bg(),cfg.fg(),cfg.dark?.073f:.050f);
        int b=Store.blend(cfg.bg(),cfg.fg(),cfg.dark?.048f:.025f);
        GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1),Store.blend(cfg.bg(),cfg.fg(),cfg.dark?.09f:.09f));
        return d;
    }
    private LinearLayout dashTile(){
        LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(wide?14:13),dp(wide?12:12),dp(wide?12:12),dp(wide?12:12));
        tile.setBackground(dashBackground(18));
        return tile;
    }
    private LinearLayout metricTitle(String caption,int iconType){
        LinearLayout title=horizontal();title.setGravity(Gravity.CENTER_VERTICAL);
        DashboardIcon icon=new DashboardIcon(this,iconType,cfg.cyan());
        LinearLayout.LayoutParams ip=lp(wide?19:17,wide?19:17);ip.rightMargin=dp(8);
        title.addView(icon,ip);
        TextView lbl=text(caption,wide?10.5f:9.7f,cfg.muted(),true);
        lbl.setSingleLine(false);lbl.setMaxLines(2);lbl.setLetterSpacing(.015f);
        title.addView(lbl,new LinearLayout.LayoutParams(0,-2,1));
        return title;
    }
    private LinearLayout metricTile(int iconType,String caption,String initial,boolean accent,int metricIndex){
        LinearLayout tile=dashTile();
        tile.addView(metricTitle(caption,iconType));
        TextView value=text(initial,wide?28:25,accent?cfg.cyan():cfg.fg(),true);
        value.setSingleLine(true);
        value.setAutoSizeTextTypeUniformWithConfiguration((int)(17*cfg.textScale),(int)((wide?29:27)*cfg.textScale),1,android.util.TypedValue.COMPLEX_UNIT_SP);
        LinearLayout.LayoutParams valLp=lp(-1,-2);valLp.topMargin=dp(wide?7:6);tile.addView(value,valLp);
        if(metricIndex==0){
            remainLabel=value;rangeBar=new RangeBarView(this);
            LinearLayout.LayoutParams barLp=lp(-1,wide?8:7);barLp.topMargin=dp(wide?9:7);
            tile.addView(rangeBar,barLp);
        } else if(metricIndex==1){tripLabel=value;}
        else if(metricIndex==2){elapsedLabel=value;}
        return tile;
    }
    private void metricGridRow(LinearLayout parent,View a,View b,int rowHeight){
        LinearLayout row=horizontal();row.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams pa=new LinearLayout.LayoutParams(0,dp(rowHeight),1);
        pa.rightMargin=dp(wide?10:8);row.addView(a,pa);
        row.addView(b,new LinearLayout.LayoutParams(0,dp(rowHeight),1));
        parent.addView(row,lp(-1,rowHeight));
    }
    private LinearLayout gpsTile(){
        LinearLayout t=dashTile();t.addView(metricTitle("ESTADO DEL GPS",DashboardIcon.SIGNAL));
        signalLabel=text("●  GPS inactivo",wide?11:10,cfg.fg(),true);
        signalLabel.setMaxLines(2);
        LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(wide?11:6);t.addView(signalLabel,p);
        return t;
    }
    private Button journeyButton(){
        Button b=button("▶  INICIAR TRAYECTO",true);
        b.setTextSize((wide?16:15)*cfg.textScale);b.setMinHeight(dp(wide?60:57));
        b.setBackground(bg(cfg.cyan(),17));
        b.setOnClickListener(v->{if(isActive())askStop();else askStart();});
        return b;
    }
    private void dashboard(){
        // Una única fuente de datos y los mismos listeners para las dos orientaciones.
        LinearLayout dial=vertical();dial.setGravity(Gravity.TOP);
        dial.setBackground(dashBackground(21));
        dial.setPadding(dp(wide?5:4),dp(wide?4:3),dp(wide?5:4),dp(wide?4:3));
        meter=new SpeedometerView(this);meter.setLayoutMode(wide,focus);
        dial.addView(meter,lp(-1,-2));

        LinearLayout metrics=vertical();
        LinearLayout autonomy=metricTile(DashboardIcon.BOLT,"AUTONOMÍA RESTANTE","-- mi",true,0);
        LinearLayout distance=metricTile(DashboardIcon.PIN,"DISTANCIA RECORRIDA","0.00 mi",false,1);
        LinearLayout time=metricTile(DashboardIcon.CLOCK,"TIEMPO DE BATERÍA","-- h",false,2);
        LinearLayout gps=gpsTile();
        int rowHeight=wide?(focus?105:99):(focus?102:97);
        metricGridRow(metrics,autonomy,distance,rowHeight);
        gap(metrics,wide?10:9);
        metricGridRow(metrics,time,gps,rowHeight);
        trackingButton=journeyButton();
        LinearLayout.LayoutParams action=lp(-1,wide?61:59);action.topMargin=dp(wide?13:12);
        metrics.addView(trackingButton,action);

        // En Focus se respeta la composición de la imagen; fuera de Focus
        // siguen estando disponibles las pestañas y el diagnóstico opcional.
        if(!focus){
            LinearLayout details=dashTile();
            modelLabel=text("Modelo inicial",11,cfg.cyan(),false);
            details.addView(modelLabel);
            tipLabel=text("Autonomía orientativa, no lectura del BMS.",10,cfg.muted(),false);
            LinearLayout.LayoutParams tp=lp(-1,-2);tp.topMargin=dp(5);details.addView(tipLabel,tp);
            LinearLayout.LayoutParams dlp=lp(-1,-2);dlp.topMargin=dp(10);metrics.addView(details,dlp);
        }
        if(wide){
            body.setOrientation(LinearLayout.HORIZONTAL);body.setGravity(Gravity.TOP);
            LinearLayout.LayoutParams left=new LinearLayout.LayoutParams(0,-2,1f);
            left.rightMargin=dp(12);body.addView(dial,left);
            body.addView(metrics,new LinearLayout.LayoutParams(0,-2,1.17f));
        }else{
            body.addView(dial,lp(-1,-2));
            LinearLayout.LayoutParams ml=lp(-1,-2);ml.topMargin=dp(12);body.addView(metrics,ml);
        }
    }
    private boolean isActive(){return RideService.live!=null||Store.prefs(this).getBoolean("ride_active",false);}
    private void refreshDashboard(){if(meter==null)return;
        RideService.Snapshot s=RideService.live==null?null:RideService.live.state;
        boolean active=isActive();
        Store.Config rideCfg=(s==null?cfg:s.rideConfig());
        double speedMps=s==null?0:s.speedMps;
        double speed=cfg.mph?speedMps*2.2369362921:speedMps*3.6;
        meter.update(speed,cfg.mph,cfg);
        double distance=s==null?0:s.miles();
        if(s==null&&active)try{JSONObject saved=new JSONObject(Store.prefs(this).getString("ride_current","{}"));
            distance=saved.optDouble("distanceM",0)/1609.344;
        }catch(Exception ignored){}
        double referenceSpeed=rideCfg.speedMph;
        if(s!=null&&speedMps>3.0)referenceSpeed=.7*rideCfg.speedMph+.3*(speedMps*2.2369362921);
        double startWh=rideCfg.usableWh(s==null?cfg.start1:s.start1,s==null?cfg.start2:s.start2);
        double consumed=active?(s==null?distance*rideCfg.whPerMile(rideCfg.speedMph):s.estimatedWh):0;
        double whLeft=Math.max(0,startWh-consumed);
        double milesLeft=whLeft/rideCfg.whPerMile(referenceSpeed);
        double showDistance=cfg.mph?distance:distance*1.609344;
        remainLabel.setText(Store.fmt(cfg.mph?milesLeft:milesLeft*1.609344,1)+(cfg.mph?" mi":" km"));
        tripLabel.setText(Store.fmt(showDistance,2)+(cfg.mph?" mi":" km"));
        double hours=milesLeft/Math.max(3,referenceSpeed);
        elapsedLabel.setText(Store.fmt(hours,1)+" h");
        if(rangeBar!=null)rangeBar.setState((float)(startWh>0?whLeft/startWh:0),cfg);
        if(runLabel!=null)runLabel.setText(s!=null?Store.duration(s.movingMs):"00:00:00");
        if(trackingButton!=null)trackingButton.setText(active?"■  FINALIZAR TRAYECTO":"▶  INICIAR TRAYECTO");
        if(trackingButton!=null){
            trackingButton.setTextColor(active?cfg.fg():cfg.bg());
            trackingButton.setBackground(active?dashBackground(17):bg(cfg.cyan(),17));
            // En Focus solo mostramos "Iniciar" antes de la ruta, no un botón para tocar conduciendo.
            trackingButton.setVisibility(View.VISIBLE);
        }
        if(signalLabel!=null){
            String status=!active?"GPS inactivo\nListo para empezar":
                    s==null?"Reconectando GPS…":s.status+(s.accuracy<100?" · ±"+Store.fmt(s.accuracy,0)+" m":"");
            String value="●  "+status;
            android.text.SpannableString colored=new android.text.SpannableString(value);
            colored.setSpan(new android.text.style.ForegroundColorSpan(!active?cfg.muted():(s==null?0xffffc857:0xff19d95b)),0,1,33);
            signalLabel.setText(colored);
        }
        if(modelLabel!=null)modelLabel.setText("Modelo "+cfg.confidence()+" · "+Store.fmt(rideCfg.whPerMile(referenceSpeed),1)+" Wh/mi · "+
                rideCfg.batteryCount+" batería"+(rideCfg.batteryCount==2?"s":"")+" · "+Store.fmt(consumed,0)+" Wh est.");
        if(tipLabel!=null)tipLabel.setText(active?"Restante = energía inicial menos consumo estimado por distancia. Sin BMS no es un % real.":
                "Calculado con "+Store.fmt(rideCfg.totalWh(),0)+" Wh nominales, reserva "+Store.fmt(rideCfg.reserve,0)+"% y salud "+Store.fmt(rideCfg.health,0)+"%.");
    }
    private EditText numeric(LinearLayout parent,String caption,double value,String unit){
        LinearLayout box=vertical();TextView label=text(caption+(unit.isEmpty()?"":"  ·  "+unit),12,cfg.muted(),true);box.addView(label);
        EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setText(Store.fmt(value,Math.floor(value)==value?0:1));e.setSelectAllOnFocus(true);e.setTextColor(cfg.fg());e.setTextSize(19*cfg.textScale);
        e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cfg.cyan()));box.addView(e,lp(-1,48));
        addMargin(parent,box,5,9);return e;
    }
    private EditText percentEdit(LinearLayout p,String title,String content){
        LinearLayout outer=vertical();outer.addView(text(title,13,cfg.muted(),false));
        EditText edit=new EditText(this);edit.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        edit.setText(content);edit.setHint("Sin dato");edit.setHintTextColor(cfg.muted());edit.setTextColor(cfg.fg());
        edit.setTextSize(23*cfg.textScale);edit.setSingleLine(true);
        edit.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cfg.cyan()));outer.addView(edit,lp(-1,55));
        p.addView(outer);return edit;
    }
    private double read(EditText e,double fallback,double min,double max){return Store.num(e.getText().toString(),fallback,min,max);}
    private void askStart(){
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},GPS_PERMISSION);return;
        }
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        if(lm!=null&&!lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)){
            alert().setTitle("Activa la ubicación")
                    .setMessage("Para medir trayectos con precisión necesitas activar el GPS del teléfono.")
                    .setPositiveButton("Abrir ajustes",(d,w)->startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
                    .setNegativeButton("Cancelar",null).show();return;
        }
        LinearLayout fields=dialogContent();
        TextView note=text("Introduce la carga disponible al empezar. Puede ser inferior al 100%.",13,cfg.fg(),false);
        fields.addView(note);gap(fields,10);
        EditText one=percentEdit(fields,"Batería A · % inicial",Store.fmt(cfg.start1,0));gap(fields,9);
        EditText two=cfg.batteryCount==2?percentEdit(fields,"Batería B · % inicial",Store.fmt(cfg.start2,0)):null;
        alert().setTitle("Nuevo trayecto")
                .setView(fields).setNegativeButton("Cancelar",null)
                .setPositiveButton("INICIAR",(d,w)->{
                    cfg.start1=read(one,cfg.start1,0,100);
                    if(two!=null)cfg.start2=read(two,cfg.start2,0,100);
                    Store.save(this,cfg);
                    Intent service=new Intent(this,RideService.class);service.setAction(RideService.START);
                    service.putExtra("start1",cfg.start1);service.putExtra("start2",cfg.start2);
                    try{startForegroundService(service);handler.postDelayed(this::refreshDashboard,600);}
                    catch(Exception e){toast("No se pudo iniciar GPS: "+e.getMessage());}
                }).show();
    }
    private LinearLayout dialogContent(){LinearLayout l=vertical();l.setPadding(dp(22),dp(6),dp(22),dp(5));return l;}
    private void askStop(){
        LinearLayout fields=dialogContent();
        fields.addView(text("¿Qué porcentaje REAL muestra ahora tu batería? Deja vacío si no sabes. Si introduces datos válidos, VoltZen aprenderá del consumo.",13,cfg.fg(),false));
        gap(fields,12);EditText a=percentEdit(fields,"Batería A · % FINAL (opcional)","");gap(fields,10);
        Store.Config rideCfg=RideService.live!=null?RideService.live.state.rideConfig():cfg;
        EditText b=rideCfg.batteryCount==2?percentEdit(fields,"Batería B · % FINAL (opcional)",""):null;
        AlertDialog dialog=alert().setTitle("Terminar y guardar")
                .setView(fields).setNegativeButton("Seguir viaje",null)
                .setNeutralButton("Sin calibrar",(d,w)->endRide(-1,-1))
                .setPositiveButton("Guardar y calibrar",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(a.getText().toString().trim().isEmpty()||(b!=null&&b.getText().toString().trim().isEmpty())){
                toast("Introduce todos los % finales o elige Sin calibrar");return;
            }
            double endA=read(a,-1,0,100);double endB=b==null?-1:read(b,-1,0,100);
            double initialA=RideService.live==null?rideCfg.start1:RideService.live.state.start1;
            double initialB=RideService.live==null?rideCfg.start2:RideService.live.state.start2;
            if(endA>initialA||(b!=null&&endB>initialB)){
                toast("El % final no puede ser mayor que el inicial. ¿Has recargado en ruta?");return;
            }
            endRide(endA,endB);dialog.dismiss();
        }));dialog.show();
    }
    private void endRide(double a,double b){
        Intent i=new Intent(this,RideService.class);i.setAction(RideService.STOP);
        i.putExtra("end1",a);i.putExtra("end2",b);
        try{startService(i);toast("Trayecto guardado en el historial");handler.postDelayed(this::render,450);}
        catch(Exception e){toast("No fue posible finalizar: "+e.getMessage());}
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private Spinner pick(LinearLayout target,String label,String[] options,int selected){
        target.addView(text(label,12,cfg.muted(),true));Spinner spinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,options){
            @Override public View getView(int pos,View convert,ViewGroup parent){TextView t=text(getItem(pos),17,cfg.fg(),true);t.setPadding(dp(6),dp(8),dp(6),dp(8));return t;}
            @Override public View getDropDownView(int pos,View convert,ViewGroup parent){TextView t=text(getItem(pos),17,Color.BLACK,false);t.setBackgroundColor(Color.WHITE);t.setPadding(dp(10),dp(12),dp(10),dp(12));return t;}
        };spinner.setAdapter(adapter);spinner.setSelection(Math.max(0,Math.min(selected,options.length-1)));
        target.addView(spinner,lp(-1,53));return spinner;
    }
    private int index(String[] values,String s){for(int i=0;i<values.length;i++)if(values[i].equals(s))return i;return 0;}
    private void bikeSettings(){
        heading("Configuración de la e-bike","Personaliza la autonomía inicial. Todos los datos quedan en el teléfono.");
        if(isActive()){TextView warning=text("Hay un viaje activo: los cambios se aplicarán al siguiente trayecto.",13,cfg.cyan(),true);
            addMargin(body,warning,0,10);}
        LinearLayout general=panel();general.addView(text("PESO TOTAL",16,cfg.fg(),true));gap(general,5);
        EditText rider=numeric(general,"Peso del conductor",cfg.riderKg,"kg");
        EditText bike=numeric(general,"Peso de la bici sin conductor",cfg.bikeKg,"kg");
        EditText acc=numeric(general,"Accesorios, mochila y carga",cfg.accessoryKg,"kg");
        addMargin(body,general,0,12);
        LinearLayout batteries=panel();batteries.addView(text("BATERÍAS",16,cfg.fg(),true));gap(batteries,10);
        String[] counts={"1 batería","2 baterías"};
        Spinner count=pick(batteries,"Número de baterías",counts,cfg.batteryCount-1);
        EditText v1=numeric(batteries,"Batería A · voltaje nominal",cfg.v1,"V");
        EditText ah1=numeric(batteries,"Batería A · capacidad",cfg.ah1,"Ah");
        LinearLayout second=vertical();
        CheckBox same=new CheckBox(this);same.setText("La segunda batería es igual a la primera");
        same.setTextColor(cfg.fg());same.setChecked(cfg.sameBattery);second.addView(same);
        LinearLayout different=vertical();
        EditText v2=numeric(different,"Batería B · voltaje nominal",cfg.v2,"V");
        EditText ah2=numeric(different,"Batería B · capacidad",cfg.ah2,"Ah");
        second.addView(different);batteries.addView(second);
        Runnable secondVisible=()->{second.setVisibility(count.getSelectedItemPosition()==1?View.VISIBLE:View.GONE);
            different.setVisibility(same.isChecked()?View.GONE:View.VISIBLE);};
        same.setOnCheckedChangeListener((b,checked)->secondVisible.run());
        count.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> a,View b,int pos,long id){secondVisible.run();}
            @Override public void onNothingSelected(android.widget.AdapterView<?> a){}
        });secondVisible.run();
        EditText reserve=numeric(batteries,"Reserva de seguridad sin utilizar",cfg.reserve,"%");
        EditText health=numeric(batteries,"Salud estimada de batería",cfg.health,"%");
        batteries.addView(text("La app suma Wh de baterías disponibles; no controla su conexión eléctrica. No conectes paquetes de distinto voltaje en paralelo.",11,cfg.muted(),false));
        addMargin(body,batteries,0,12);
        LinearLayout conditions=panel();conditions.addView(text("CONDUCCIÓN",16,cfg.fg(),true));gap(conditions,8);
        String[] tireKeys={"road","mtb","fat"};
        Spinner tire=pick(conditions,"Neumáticos",new String[]{"Carretera / urbanos","MTB","Fat bike 4.0"},index(tireKeys,cfg.tire));
        String[] terrainKeys={"flat","mixed","hills"};
        Spinner terrain=pick(conditions,"Terreno habitual",new String[]{"Principalmente llano","Mixto","Con muchas pendientes"},index(terrainKeys,cfg.terrain));
        String[] assistKeys={"eco","normal","turbo"};
        Spinner assist=pick(conditions,"Asistencia del motor",new String[]{"Eco / pedaleo alto","Normal","Turbo / pedaleo bajo"},index(assistKeys,cfg.assist));
        String[] windKeys={"none","light","strong"};
        Spinner wind=pick(conditions,"Resistencia del viento",new String[]{"Poca","Brisa moderada","Viento fuerte"},index(windKeys,cfg.wind));
        EditText speed=numeric(conditions,"Velocidad media prevista",cfg.speedMph,"mph");
        addMargin(body,conditions,0,12);
        Button save=button("GUARDAR CONFIGURACIÓN",true);
        save.setOnClickListener(w->{
            cfg.riderKg=read(rider,cfg.riderKg,20,300);cfg.bikeKg=read(bike,cfg.bikeKg,5,120);
            cfg.accessoryKg=read(acc,cfg.accessoryKg,0,120);
            cfg.batteryCount=count.getSelectedItemPosition()+1;cfg.sameBattery=same.isChecked();
            cfg.v1=read(v1,cfg.v1,12,100);cfg.ah1=read(ah1,cfg.ah1,1,100);
            cfg.v2=read(v2,cfg.v2,12,100);cfg.ah2=read(ah2,cfg.ah2,1,100);
            cfg.reserve=read(reserve,cfg.reserve,0,50);cfg.health=read(health,cfg.health,30,100);
            cfg.speedMph=read(speed,cfg.speedMph,3,45);
            cfg.tire=tireKeys[tire.getSelectedItemPosition()];
            cfg.terrain=terrainKeys[terrain.getSelectedItemPosition()];
            cfg.assist=assistKeys[assist.getSelectedItemPosition()];
            cfg.wind=windKeys[wind.getSelectedItemPosition()];
            Store.save(this,cfg);toast("Configuración guardada");tab=0;render();
        });body.addView(save,lp(-1,58));gap(body,15);
        body.addView(text("Estimación actual: "+Store.fmt(cfg.rangeMiles(cfg.start1,cfg.start2,cfg.speedMph),1)+" mi desde la carga configurada. Sin telemetría eléctrica la precisión es limitada.",12,cfg.muted(),false));
    }
    private void history(){
        heading("Historial de trayectos","Todo se guarda localmente. Los viajes calibrados mejoran la estimación.");
        Store.Config c=Store.config(this);
        LinearLayout model=panel();model.addView(text("APRENDIZAJE DE AUTONOMÍA",12,cfg.muted(),true));
        TextView confidence=text(c.confidence(),27,cfg.cyan(),true);addMargin(model,confidence,5,5);
        model.addView(text(c.learningRides+" trayectos calibrados · "+Store.fmt(c.learningMiles,1)+" mi aprendidas",13,cfg.fg(),false));
        model.addView(text("Factor personal: "+Store.fmt(c.learningRatio,2)+"× sobre el modelo físico. A más trayectos con porcentajes reales, más útil será.",12,cfg.muted(),false));
        addMargin(body,model,0,13);
        List<JSONObject> list=Store.trips(this);
        LinearLayout actions=horizontal();
        Button export=button("EXPORTAR CSV",false);Button reset=button("REINICIAR MODELO",false);
        LinearLayout.LayoutParams aa=new LinearLayout.LayoutParams(0,dp(52),1);aa.rightMargin=dp(6);
        actions.addView(export,aa);actions.addView(reset,new LinearLayout.LayoutParams(0,dp(52),1));
        export.setOnClickListener(v->exportCsv());reset.setOnClickListener(v->confirmReset());
        addMargin(body,actions,0,13);
        if(list.isEmpty()){LinearLayout none=panel();none.addView(text("Todavía no hay trayectos",18,cfg.fg(),true));gap(none,8);
            none.addView(text("Inicia uno desde VELOCIDAD. Al terminar, introduce los % finales si los sabes; si no, igualmente se guardará la distancia.",13,cfg.muted(),false));
            body.addView(none);return;}
        int count=0;for(JSONObject trip:list){
            if(count++>=60)break;
            LinearLayout card=panel();String date=DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT,Locale.getDefault())
                    .format(new Date(trip.optLong("date",System.currentTimeMillis())));
            card.addView(text(date,13,cfg.muted(),true));
            double mi=trip.optDouble("distanceMi",0);
            addMargin(card,text(Store.fmt(cfg.mph?mi:mi*1.609344,2)+(cfg.mph?" mi":" km"),26,cfg.fg(),true),7,3);
            String row="Movimiento "+Store.duration(trip.optLong("movingMs",0))+
                    " · Media "+Store.fmt(trip.optDouble("avgMph",0)*(cfg.mph?1:1.609344),0)+(cfg.mph?" mph":" km/h");
            card.addView(text(row,12,cfg.muted(),false));
            card.addView(text(trip.optBoolean("calibrated",false)?"✓  Calibrado con consumo declarado":"○  Sin calibrar",12,
                    trip.optBoolean("calibrated",false)?cfg.cyan():cfg.muted(),true));
            card.setOnClickListener(v->tripDetails(trip));addMargin(body,card,0,9);
        }
        Button clear=button("BORRAR HISTORIAL",false);addMargin(body,clear,8,0);
        clear.setOnClickListener(v->alert().setTitle("¿Borrar trayectos?")
                .setMessage("Se eliminará el historial guardado, pero no la calibración. Puedes reiniciarla por separado.")
                .setNegativeButton("Cancelar",null).setPositiveButton("BORRAR",(d,w)->{Store.clearTrips(this);render();}).show());
    }
    private void tripDetails(JSONObject t){Store.Config used=Store.Config.fromJson(t.optJSONObject("config"));
        String msg="Distancia: "+Store.fmt(t.optDouble("distanceMi",0),2)+" mi\n"+
                "Tiempo total: "+Store.duration(t.optLong("durationMs",0))+"\n"+
                "Tiempo en movimiento: "+Store.duration(t.optLong("movingMs",0))+"\n"+
                "Velocidad máxima: "+Store.fmt(t.optDouble("maxMph",0),1)+" mph\n"+
                "Velocidad media: "+Store.fmt(t.optDouble("avgMph",0),1)+" mph\n"+
                "Consumo de modelo: "+Store.fmt(t.optDouble("estimatedWh",0),0)+" Wh estimados\n"+
                "Subida GPS aproximada: "+Store.fmt(t.optDouble("climbM",0),0)+" m\n"+
                "Baterías: "+used.batteryCount+" · "+Store.fmt(used.totalWh(),0)+" Wh nominales\n"+
                "Carga A: "+Store.fmt(t.optDouble("start1",100),0)+"% → "+
                (t.optDouble("end1",-1)>=0?Store.fmt(t.optDouble("end1",0),0)+"%":"no indicado")+"\n"+
                (used.batteryCount==2?"Carga B: "+Store.fmt(t.optDouble("start2",100),0)+"% → "+
                    (t.optDouble("end2",-1)>=0?Store.fmt(t.optDouble("end2",0),0)+"%":"no indicado")+"\n":"")+
                "Puntos GPS válidos: "+t.optInt("accepted",0)+"\n"+
                "Puntos GPS rechazados: "+t.optInt("rejected",0)+"\n"+
                (t.optBoolean("calibrated",false)?"Datos usados para aprender.":"Sin datos fiables para aprender.");
        alert().setTitle("Detalle del trayecto").setMessage(msg).setPositiveButton("Cerrar",null).show();
    }
    private void confirmReset(){alert().setTitle("Reiniciar aprendizaje")
            .setMessage("Se perderá el factor personalizado; el historial permanecerá intacto.")
            .setNegativeButton("Cancelar",null).setPositiveButton("REINICIAR",(d,w)->{
                cfg=Store.config(this);cfg.learningRatio=1;cfg.learningMiles=0;cfg.learningRides=0;Store.save(this,cfg);render();
            }).show();}
    private String csv(){StringBuilder b=new StringBuilder();
        b.append("inicio_utc,final_utc,distancia_mi,tiempo_total_seg,tiempo_movimiento_seg,velocidad_max_mph,ascenso_m,carga_a_inicio,carga_a_final,carga_b_inicio,carga_b_final,baterias,calibrado,puntos_validos,puntos_rechazados\n");
        for(JSONObject j:Store.trips(this)){
            Store.Config c=Store.Config.fromJson(j.optJSONObject("config"));
            b.append(j.optLong("date",0)).append(',').append(j.optLong("end",0)).append(',')
            .append(String.format(Locale.US,"%.3f",j.optDouble("distanceMi",0))).append(',')
            .append(j.optLong("durationMs",0)/1000).append(',').append(j.optLong("movingMs",0)/1000).append(',')
            .append(String.format(Locale.US,"%.2f",j.optDouble("maxMph",0))).append(',')
            .append(String.format(Locale.US,"%.1f",j.optDouble("climbM",0))).append(',')
            .append(j.optDouble("start1",-1)).append(',').append(j.optDouble("end1",-1)).append(',')
            .append(j.optDouble("start2",-1)).append(',').append(j.optDouble("end2",-1)).append(',')
            .append(c.batteryCount).append(',').append(j.optBoolean("calibrated",false)).append(',')
            .append(j.optInt("accepted",0)).append(',').append(j.optInt("rejected",0)).append('\n');
        }return b.toString();}
    private void exportCsv(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"VoltZen_trayectos.csv");
        try{startActivityForResult(i,EXPORT_CSV);}catch(Exception e){toast("No se pudo abrir el selector de archivos");}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
        if(req==EXPORT_CSV&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                if(out!=null){out.write(csv().getBytes(StandardCharsets.UTF_8));toast("CSV exportado correctamente");}
            }catch(Exception e){toast("Error exportando CSV: "+e.getMessage());}
        }
    }
    private CheckBox check(LinearLayout parent,String label,boolean value){CheckBox b=new CheckBox(this);
        b.setText(label);b.setTextColor(cfg.fg());b.setTextSize(14*cfg.textScale);b.setChecked(value);
        b.setButtonTintList(android.content.res.ColorStateList.valueOf(cfg.cyan()));
        parent.addView(b,lp(-1,51));return b;}
    private void settingsPage(){
        heading("Ajustes","Pantalla despejada y colores adaptables a tu conducción.");
        LinearLayout display=panel();display.addView(text("PANTALLA Y LEGIBILIDAD",15,cfg.fg(),true));gap(display,8);
        CheckBox mph=check(display,"Usar millas y MPH (UK)",cfg.mph);
        CheckBox dark=check(display,"Modo oscuro",cfg.dark);
        CheckBox wake=check(display,"Mantener pantalla encendida",cfg.keepAwake);
        display.addView(text("Orientación de pantalla",13,cfg.muted(),true));
        Spinner screenMode=pick(display,"Horizontal, vertical o girar con el móvil",
                new String[]{"Automática (sensor del teléfono)","Siempre vertical","Siempre horizontal"},cfg.orientationMode);
        display.addView(text("También puedes tocar ▭ / ▯ en el tablero para girar rápidamente.",11,cfg.muted(),false));
        display.addView(text("Tamaño de textos",13,cfg.muted(),true));
        TextView size=text(Store.fmt(cfg.textScale*100,0)+"%",21,cfg.cyan(),true);display.addView(size);
        SeekBar scale=new SeekBar(this);scale.setMax(65);scale.setProgress((int)(cfg.textScale*100)-85);scale.setProgressTintList(android.content.res.ColorStateList.valueOf(cfg.cyan()));
        scale.setThumbTintList(android.content.res.ColorStateList.valueOf(cfg.cyan()));display.addView(scale,lp(-1,45));
        scale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int val,boolean fromUser){size.setText((85+val)+"%");}
            public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
        });addMargin(body,display,0,12);
        LinearLayout gps=panel();gps.addView(text("SEGUIMIENTO GPS",15,cfg.fg(),true));gap(gps,10);
        EditText accuracy=numeric(gps,"Precisión máxima admitida (10–50)",cfg.gpsAccuracy,"metros");
        gps.addView(text("Un filtro estricto reduce saltos falsos, pero puede perder distancia en túneles o zonas con mala señal. Recomendado: 25 m.",12,cfg.muted(),false));
        addMargin(body,gps,0,12);
        Button save=button("GUARDAR PREFERENCIAS",true);save.setOnClickListener(v->{
            cfg.mph=mph.isChecked();cfg.dark=dark.isChecked();cfg.keepAwake=wake.isChecked();
            cfg.textScale=(85+scale.getProgress())/100f;cfg.gpsAccuracy=read(accuracy,cfg.gpsAccuracy,10,50);
            cfg.orientationMode=screenMode.getSelectedItemPosition();
            Store.save(this,cfg);applyOrientation();render();toast("Preferencias guardadas");
        });body.addView(save,lp(-1,55));gap(body,14);
        LinearLayout colors=panel();colors.addView(text("COLORES PERSONALIZABLES",15,cfg.fg(),true));
        gap(colors,6);colors.addView(text("Tres colores independientes para cada tema.",12,cfg.muted(),false));
        colorLine(colors,"OSCURO",true);colorLine(colors,"CLARO",false);
        addMargin(body,colors,0,13);
        LinearLayout about=panel();about.addView(text("CÓMO FUNCIONA VOLTZEN",15,cfg.fg(),true));gap(about,9);
        about.addView(text("1. Introduce capacidad, peso, recorrido habitual y nivel de asistencia.\n\n"+
                "2. Inicia el trayecto con el móvil bien fijado. La distancia se calcula por GPS, sin sumar paradas ni picos evidentes.\n\n"+
                "3. Al finalizar, indica los porcentajes de batería A/B que observaste. Solo datos declarados válidos se usan para calibrar.\n\n"+
                "4. La app aprende Wh/mi y ajusta la autonomía futura. No existe lectura real del BMS: los porcentajes y el consumo están sujetos a error.\n\n"+
                "Ubicación y trayectos se almacenan solo en este móvil; no hay Internet, cuenta, anuncios ni rastreadores.",13,cfg.muted(),false));
        addMargin(body,about,0,10);
        body.addView(text("VoltZen 1.2.0 · Proyecto GL&C · Android 8.0+",11,cfg.muted(),false));
    }
    private void colorLine(LinearLayout target,String label,boolean darkTheme){
        addMargin(target,text(label,12,cfg.muted(),true),15,4);
        LinearLayout line=horizontal();String[] names={"Fondo","Texto","Neón"};
        for(int i=0;i<3;i++){
            final int slot=i;final int value=getColor(darkTheme,i);
            LinearLayout entry=vertical();entry.setGravity(Gravity.CENTER);entry.setPadding(dp(4),dp(4),dp(4),dp(4));
            View sample=new View(this);sample.setBackground(bg(value,8));
            entry.addView(sample,lp(62,35));
            TextView cap=text(names[i],11,cfg.fg(),false);cap.setGravity(Gravity.CENTER);
            addMargin(entry,cap,5,0);
            entry.setOnClickListener(v->colorDialog(darkTheme,slot));
            line.addView(entry,new LinearLayout.LayoutParams(0,dp(78),1));
        }target.addView(line);
    }
    private int getColor(boolean d,int slot){return d?(slot==0?cfg.darkBg:slot==1?cfg.darkText:cfg.darkAccent):
            (slot==0?cfg.lightBg:slot==1?cfg.lightText:cfg.lightAccent);}
    private void setColor(boolean d,int slot,int v){
        if(d){if(slot==0)cfg.darkBg=v;else if(slot==1)cfg.darkText=v;else cfg.darkAccent=v;}
        else{if(slot==0)cfg.lightBg=v;else if(slot==1)cfg.lightText=v;else cfg.lightAccent=v;}
    }
    private void colorDialog(boolean darkTheme,int slot){
        int start=getColor(darkTheme,slot);LinearLayout fields=dialogContent();
        TextView hex=text(String.format(Locale.US,"#%06X",start&0xFFFFFF),22,cfg.fg(),true);
        fields.addView(hex);gap(fields,12);
        View preview=new View(this);preview.setBackground(bg(start,10));fields.addView(preview,lp(-1,54));gap(fields,12);
        int[] channels={Color.red(start),Color.green(start),Color.blue(start)};
        String[] channelNames={"ROJO","VERDE","AZUL"};
        for(int i=0;i<3;i++){
            final int index=i;fields.addView(text(channelNames[i],12,cfg.fg(),false));
            SeekBar bar=new SeekBar(this);bar.setMax(255);bar.setProgress(channels[i]);fields.addView(bar);
            bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar b,int value,boolean user){channels[index]=value;
                    int next=Color.rgb(channels[0],channels[1],channels[2]);
                    hex.setText(String.format(Locale.US,"#%06X",next&0xFFFFFF));preview.setBackground(bg(next,10));}
                public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}
            });
        }
        alert().setTitle("Color · "+(darkTheme?"oscuro":"claro"))
                .setView(fields).setNegativeButton("Cancelar",null)
                .setPositiveButton("APLICAR",(d,w)->{setColor(darkTheme,slot,Color.rgb(channels[0],channels[1],channels[2]));
                    Store.save(this,cfg);render();}).show();
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==GPS_PERMISSION){
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)askStart();
            else alert().setTitle("Se necesita ubicación precisa")
                .setMessage("Sin permiso de ubicación precisa no es posible medir los kilómetros del trayecto.")
                .setPositiveButton("Entendido",null).show();
        }
    }
}
