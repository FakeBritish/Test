package com.glc.voltzen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.View;

/** Velocímetro VoltZen 1.2: aro iluminado, escala precisa y contraste de alto nivel. */
public class SpeedometerView extends View {
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private double speed=0,max=40;
    private String unit="MPH";
    private int background=0xff060b12,foreground=Color.WHITE,accent=0xff16e2f1,muted=0xff8a9ba7;
    private float scale=1.0f;
    private boolean landscape=false,focus=false;
    public SpeedometerView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setLayoutMode(boolean isLandscape,boolean focusMode){landscape=isLandscape;focus=focusMode;requestLayout();invalidate();}
    public void update(double newSpeed,boolean useMph,Store.Config cfg){
        speed=Math.max(0,newSpeed);max=useMph?40:65;unit=useMph?"MPH":"KM/H";
        background=cfg.bg();foreground=cfg.fg();accent=cfg.cyan();muted=cfg.muted();scale=cfg.textScale;invalidate();
    }
    private float dp(float v){return v*getResources().getDisplayMetrics().density;}
    @Override protected void onMeasure(int wSpec,int hSpec){
        int width=MeasureSpec.getSize(wSpec);
        int target=landscape?Math.min((int)dp(335),Math.max((int)dp(223),(int)(width*.81f))):
                Math.min((int)dp(360),Math.max((int)dp(290),(int)(width*.93f)));
        if(MeasureSpec.getMode(hSpec)==MeasureSpec.AT_MOST)target=Math.min(target,MeasureSpec.getSize(hSpec));
        if(MeasureSpec.getMode(hSpec)==MeasureSpec.EXACTLY)target=MeasureSpec.getSize(hSpec);
        setMeasuredDimension(width,target);
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight(),cx=w*.5f,cy=h*.485f;
        float r=Math.min(w*.421f,h*.449f);
        float start=137f,sweep=267f;
        p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.BUTT);
        // Aro exterior muy sutil y borde interior.
        p.setColor(Store.blend(background,foreground,.055f));p.setStrokeWidth(dp(1));
        c.drawCircle(cx,cy,r+dp(17),p);
        p.setColor(Store.blend(background,foreground,.032f));c.drawCircle(cx,cy,r-dp(15),p);
        RectF outer=new RectF(cx-r,cy-r,cx+r,cy+r);
        p.setStrokeCap(Paint.Cap.BUTT);p.setStrokeWidth(Math.max(dp(10),r*.088f));
        p.setColor(Store.blend(background,foreground,.125f));c.drawArc(outer,start,sweep,false,p);
        // Segmento cian iluminado: parte de la estética de VoltZen, no un porcentaje de batería.
        p.setColor(accent);p.setStrokeCap(Paint.Cap.BUTT);
        p.setShadowLayer(dp(12),0,0,accent);
        c.drawArc(outer,start,136f,false,p);p.clearShadowLayer();
        // Ticks elegantes y no invasivos alrededor de la escala.
        p.setStrokeCap(Paint.Cap.ROUND);
        for(int i=0;i<=44;i++){
            float a=(float)Math.toRadians(start+i*sweep/44f);
            float outerTick=r-dp(13),innerTick=outerTick-(i%5==0?dp(11):dp(5));
            p.setColor(Store.blend(background,foreground,i%5==0?.52f:.25f));
            p.setStrokeWidth(i%5==0?dp(1.1f):dp(.7f));
            c.drawLine(cx+(float)Math.cos(a)*innerTick,cy+(float)Math.sin(a)*innerTick,
                    cx+(float)Math.cos(a)*outerTick,cy+(float)Math.sin(a)*outerTick,p);
        }
        // Marcador real de velocidad: independiente del segmento de luz decorativo.
        float marker=(float)Math.toRadians(start+(float)(Math.min(speed/max,1)*sweep));
        p.setStyle(Paint.Style.FILL);p.setColor(foreground);
        c.drawCircle(cx+(float)Math.cos(marker)*(r-dp(24)),cy+(float)Math.sin(marker)*(r-dp(24)),dp(2.2f),p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        p.setColor(muted);p.setTextSize(Math.max(dp(10),Math.min(dp(13)*scale,r*.105f)));
        c.drawText("VELOCIDAD GPS",cx,cy-r*.315f,p);
        // Número principal. El mínimo con ajuste de escala evita que se recorte a altas velocidades.
        String digits=Store.fmt(speed,0);
        p.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));p.setColor(foreground);
        float font=Math.min(r*.96f,dp(126)*scale);
        p.setTextSize(font);
        while(p.measureText(digits)>r*1.38f && font>dp(45)){font*=.92f;p.setTextSize(font);}
        c.drawText(digits,cx,cy+r*.31f,p);
        p.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));p.setColor(accent);
        p.setTextSize(Math.min(dp(23)*scale,r*.19f));
        c.drawText(unit,cx,cy+r*.53f,p);
        p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setColor(muted);
        p.setTextSize(Math.min(dp(10.5f)*scale,r*.088f));
        c.drawText("V E L O C I D A D   A C T U A L",cx,cy+r*.79f,p);
        p.setStrokeCap(Paint.Cap.ROUND);p.setStyle(Paint.Style.STROKE);p.setColor(accent);
        p.setShadowLayer(dp(6),0,0,accent);p.setStrokeWidth(dp(3));
        c.drawLine(cx-dp(19),cy+r*.89f,cx+dp(19),cy+r*.89f,p);p.clearShadowLayer();
        p.setStyle(Paint.Style.FILL);
    }
}
