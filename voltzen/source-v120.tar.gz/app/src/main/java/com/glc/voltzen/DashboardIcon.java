package com.glc.voltzen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Iconos vectoriales nativos del tablero: sin recursos de Internet. */
public final class DashboardIcon extends View {
    public static final int BOLT=0, PIN=1, CLOCK=2, SIGNAL=3, EXIT=4, PLAY=5;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int type,color;
    public DashboardIcon(Context context,int type,int color){super(context);this.type=type;this.color=color;}
    private void line(Canvas c,float x1,float y1,float x2,float y2){c.drawLine(x1,y1,x2,y2,p);}
    @Override protected void onDraw(Canvas c){super.onDraw(c);
        int save=c.save();float s=Math.min(getWidth(),getHeight())/24f;
        c.translate((getWidth()-24*s)/2,(getHeight()-24*s)/2);c.scale(s,s);
        p.setColor(color);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeWidth(2f);
        p.setStyle(Paint.Style.STROKE);
        switch(type){
            case BOLT:{
                p.setStyle(Paint.Style.FILL);Path b=new Path();
                b.moveTo(13,0);b.lineTo(4,13);b.lineTo(10,13);b.lineTo(8,24);
                b.lineTo(21,9.5f);b.lineTo(14.5f,9.5f);b.close();c.drawPath(b,p);break;
            }
            case PIN:{
                Path path=new Path();path.moveTo(12,22);path.cubicTo(9,17,4,13,4,9);
                path.cubicTo(4,4,7.6f,2,12,2);path.cubicTo(16.4f,2,20,4,20,9);
                path.cubicTo(20,13,15,17,12,22);path.close();p.setStyle(Paint.Style.FILL);c.drawPath(path,p);
                p.setColor(0xff09151e);c.drawCircle(12,9,2.9f,p);break;
            }
            case CLOCK:{
                c.drawCircle(12,12,9,p);line(c,12,6.8f,12,12);line(c,12,12,16.2f,14.5f);break;
            }
            case SIGNAL:{
                c.drawCircle(12,12,1.9f,p);
                c.drawArc(new RectF(5,5,19,19),-53,106,false,p);
                c.drawArc(new RectF(5,5,19,19),127,106,false,p);
                c.drawArc(new RectF(1.5f,1.5f,22.5f,22.5f),-55,110,false,p);
                c.drawArc(new RectF(1.5f,1.5f,22.5f,22.5f),125,110,false,p);break;
            }
            case EXIT:{
                Path door=new Path();door.moveTo(12,3);door.lineTo(5,3);door.lineTo(5,21);
                door.lineTo(12,21);c.drawPath(door,p);line(c,10,12,22,12);
                line(c,18,8,22,12);line(c,22,12,18,16);break;
            }
            case PLAY:{
                p.setStyle(Paint.Style.FILL);Path play=new Path();play.moveTo(6,3);
                play.lineTo(21,12);play.lineTo(6,21);play.close();c.drawPath(play,p);break;
            }
        }
        c.restoreToCount(save);
    }
}
