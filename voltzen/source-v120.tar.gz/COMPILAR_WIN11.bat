@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title VoltZen - Compilar APK Android en Windows 11

echo.
echo  ====================================================
echo           VOLTZEN 1.2 - COMPILADOR WINDOWS 11
echo  ====================================================
echo.

rem Se prefiere el JDK que ya trae Android Studio (Java 17+).
if not defined JAVA_HOME if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "PATH=%JAVA_HOME%\bin;%PATH%"
where java >nul 2>nul
if errorlevel 1 (
  echo [ERROR] No se encontró Java.
  echo Instala Android Studio o un JDK 17/21 y vuelve a ejecutar este archivo.
  echo https://developer.android.com/studio
  goto :fail
)
java -version 2>&1 | findstr /i "version" >nul
if errorlevel 1 (echo [ERROR] Java no funciona correctamente. & goto :fail)

rem Detectar el SDK de Android instalado por Android Studio.
if defined ANDROID_SDK_ROOT (
  set "SDK=!ANDROID_SDK_ROOT!"
) else if defined ANDROID_HOME (
  set "SDK=!ANDROID_HOME!"
) else (
  set "SDK=%LOCALAPPDATA%\Android\Sdk"
)
if not exist "!SDK!" mkdir "!SDK!"
set "ANDROID_HOME=!SDK!"
set "ANDROID_SDK_ROOT=!SDK!"
echo [OK] Java detectado.
echo [INFO] Android SDK: !SDK!

rem Instalar command-line tools si Android Studio todavía no las tiene.
set "SDKMGR=!SDK!\cmdline-tools\latest\bin\sdkmanager.bat"
if not exist "!SDKMGR!" (
  echo [INFO] Descargando herramientas oficiales de Android...
  set "SDK_ZIP=%TEMP%\voltzen_android_cli.zip"
  set "SDK_UNZIP=%TEMP%\voltzen_android_cli"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' -OutFile $env:SDK_ZIP; if((Get-FileHash $env:SDK_ZIP -Algorithm SHA256).Hash.ToLower() -ne '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'){ throw 'La descarga SDK no paso SHA256' }; if(Test-Path $env:SDK_UNZIP){Remove-Item $env:SDK_UNZIP -Recurse -Force}; Expand-Archive -Path $env:SDK_ZIP -DestinationPath $env:SDK_UNZIP -Force; New-Item -ItemType Directory -Force -Path (Join-Path $env:ANDROID_HOME 'cmdline-tools') | Out-Null; Move-Item -Path (Join-Path $env:SDK_UNZIP 'cmdline-tools') -Destination (Join-Path $env:ANDROID_HOME 'cmdline-tools\latest') -Force"
  if errorlevel 1 (echo [ERROR] No se pudieron descargar las herramientas Android. & goto :fail)
)
if not exist "!SDKMGR!" (echo [ERROR] sdkmanager no disponible en !SDKMGR! & goto :fail)
if not exist "!SDK!\platforms\android-35\android.jar" (
  echo [INFO] Aceptando licencias e instalando SDK Android 35...
  (for /L %%N in (1,1,40) do @echo y) | call "!SDKMGR!" --sdk_root="!SDK!" --licenses >nul
  call "!SDKMGR!" --sdk_root="!SDK!" "platforms;android-35" "build-tools;35.0.0" "platform-tools"
  if errorlevel 1 (echo [ERROR] No se pudo instalar Android SDK 35. & goto :fail)
)

rem Descargar Gradle una única vez. La caché queda dentro de este proyecto.
set "GRADLE_DIR=%~dp0.tools\gradle-8.11.1"
set "GRADLE_BAT=!GRADLE_DIR!\bin\gradle.bat"
if not exist "!GRADLE_BAT!" (
  echo [INFO] Descargando Gradle oficial 8.11.1 (solo la primera vez)...
  if not exist ".tools" mkdir ".tools"
  set "GRADLE_ZIP=%~dp0.tools\gradle-8.11.1-bin.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $env:GRADLE_ZIP; Expand-Archive -LiteralPath $env:GRADLE_ZIP -DestinationPath '.tools' -Force"
  if errorlevel 1 (echo [ERROR] No se pudo descargar Gradle. & goto :fail)
)
if not exist "!GRADLE_BAT!" (echo [ERROR] Gradle no se encontró. & goto :fail)
echo.
echo [INFO] Compilando la misma app VoltZen v1.2.0...
call "!GRADLE_BAT!" --no-daemon --stacktrace :app:assembleDebug
if errorlevel 1 (echo [ERROR] Fallo al compilar. Revisa el error de Gradle. & goto :fail)
if not exist "app\build\outputs\apk\debug\app-debug.apk" (echo [ERROR] No se generó el APK. & goto :fail)
if not exist "APK" mkdir "APK"
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "APK\VoltZen-v1.2.0-debug.apk" >nul
if errorlevel 1 (echo [ERROR] No se pudo copiar el APK. & goto :fail)
echo.
echo  ====================================================
echo  [LISTO] APK FIRMADA PARA INSTALAR:
echo  %~dp0APK\VoltZen-v1.2.0-debug.apk
echo  ====================================================
echo.
echo Nota: es una APK debug firmada automaticamente por Android.
echo Para distribuir en Google Play necesitas una firma release propia.
echo.
explorer "APK"
pause
exit /b 0
:fail
echo.
echo No se generó la APK. Comprueba el error anterior.
pause
exit /b 1
