# VoltZen 1.2.0 · Tablero adaptativo + modo Focus

Novedades: orientación automática por sensor, bloqueo manual vertical u horizontal, botón de cambio rápido, panel adaptativo de dos columnas en horizontal, modo Focus persistente con datos esenciales y acciones de conducción simplificadas. Se conserva la lógica de GPS, baterías, aprendizaje e historial.

**Importante para actualizaciones:** Las APK debug de GitHub Actions y las compiladas en Windows pueden estar firmadas con claves diferentes. Android puede impedir la actualización sobre versiones previas. Haz copia CSV de tus trayectos antes de desinstalar.

# VoltZen 1.2.0 — e-bike smart dashboard (Android)

**Proyecto completo en Java nativo para Android, sin servidores, anuncios ni SDK externos.**

## Cómo obtener la APK en Windows 11

1. Descomprime este ZIP en una carpeta local (por ejemplo `C:\VoltZen`).
2. Haz doble clic en `COMPILAR_WIN11.bat` con conexión a Internet.
3. Si tienes Android Studio, el `.bat` aprovechará su Java y Android SDK. Si faltan las herramientas de comandos, Android API 35 o Gradle, intentará descargarlas automáticamente de los servidores oficiales.
4. En el primer uso, confirma la instalación de componentes/licencias si es necesario. El proceso requiere espacio en disco y acceso a `dl.google.com`, `services.gradle.org` y repositorios Maven de Google.
5. Al terminar, estará en **`APK\VoltZen-v1.2.0-debug.apk`**. Es una APK Android firmada con la clave **debug** de tu equipo, instalable en el teléfono. No es firma de publicación Google Play.

**Requisitos:** Windows 11, Java 17+ (incluido normalmente en Android Studio), conexión de red al menos para la primera compilación y un SDK Android instalable. Android 8.0 o superior para usar la app. Para instalar desde el teléfono, permite temporalmente instalar apps de esa procedencia.

**Alternativa con GitHub Actions:** se incluye `.github/workflows/android-build.yml`: si subes el proyecto a tu propio repositorio GitHub con Actions habilitado, se generará el APK como artefacto descargable tras cada `push` a `main`, o al ejecutar manualmente el flujo. No es necesario Android Studio en ese caso.

## Funciones

- Velocímetro GPS con dial grande y MPH/km/h, cifras legibles y navegación con cuatro secciones.
- Distancia recorrida y tiempo **en movimiento**. El filtrado GPS rechaza posiciones de baja precisión, picos de velocidad y saltos tras pérdida de señal; al detenerse deja de sumar.
- Servicio de localización de primer plano con notificación persistente; continúa al cambiar de aplicación y con la pantalla apagada, sujeto a permisos/restricciones de batería del fabricante.
- Una o dos baterías de **cualquier capacidad configurada**: Wh = voltaje nominal × Ah. La segunda puede ser idéntica sin repetir el formulario, o de voltaje/capacidad distintos.
- Configurables: peso conductor, bici, accesorios, velocidad prevista, tipo de ruedas, terreno, asistencia, viento, reserva y salud de batería.
- Estimación inicial basada en resistencias física aerodinámica, rodadura y ascenso, con factores de asistencia, eficiencia y condiciones (estimación no homologada).
- Tiempo y distancia estimados hasta la **reserva de seguridad**, NO un indicador real del BMS.
- Al finalizar cada viaje puedes registrar el porcentaje final de cada batería. Si se cumplen las condiciones de calidad, la app adapta su factor Wh/mi utilizando el consumo declarado.
- Historial local, pantalla de detalle y exportación CSV.
- Modo oscuro (negro/blanco/cian predeterminado) y claro, con tres colores RGB independientes en cada uno.
- Aumento de tamaño de texto, pantalla encendida y umbral de precisión GPS configurable.
- No guarda coordenadas GPS ni requiere conexión a Internet para funcionar.

## Advertencias de precisión y seguridad

- **No hay conexión Bluetooth BMS, sensor de corriente ni lectura del nivel real.** Un teléfono por sí solo no conoce el consumo eléctrico ni la carga verdadera de la bicicleta. Para calibrar, debes introducir los porcentajes que has observado, idealmente del propio BMS; porcentajes estimados por barras/voltaje pueden ser imprecisos.
- En baterías dobles se requiere el porcentaje final de **ambas** para una calibración completa; los Wh se suman para estimar autonomía, pero esto **no** significa que sea seguro conectar en paralelo baterías de voltajes distintos. Nunca conectes paquetes distintos sin el equipo eléctrico apropiado.
- No se suman kilómetros si no hay GPS fiable, incluso si la bici sí está avanzando (p. ej. túneles). El filtrado puede perder tramos lentos y no garantiza eliminar absolutamente todo el ruido. La velocidad GPS no sustituye a un velocímetro homologado.
- Los errores de capacidad real, masa, presión de neumáticos, temperatura, desnivel, viento, rutas, pedaleo, salud de batería y voltaje provocan desviaciones. El cálculo inicial es orientativo; el aprendizaje requiere varios trayectos variados y buenos datos de consumo.
- En Samsung y otros fabricantes, configura la batería de VoltZen como **Sin restricciones** para que el seguimiento sobreviva mejor al apagado de pantalla. Mantén el GPS y la ubicación precisa activados.
- Monta el teléfono en un soporte fiable. Cambia configuraciones únicamente cuando estés detenido.

## Valores iniciales

De fábrica se crea un ejemplo cercano a una fat e-bike: **2 × 48 V 20 Ah**, baterías iguales, conductor 110 kg, bici 34 kg y 6 kg de accesorios, fat tires, velocidad 16 mph y 12 % de reserva. **No significa que la app haya detectado tu bici.** Personaliza estos valores antes de salir.

## Estructura

- `app/src/main/java/com/glc/voltzen/Store.java`: almacenamiento, autonomía y aprendizaje.
- `RideService.java`: recepción/filtrado GPS, notificación, sesiones y recuperación.
- `MainActivity.java`: pantallas y controles nativos.
- `SpeedometerView.java`: dial velocidad.
- `AndroidManifest.xml`: permisos y servicio GPS.
- `COMPILAR_WIN11.bat`: prepara herramientas y genera APK firmada de depuración.

Licencia de uso de este código: puedes modificarlo y compilarlo libremente para tus proyectos personales. Este paquete no contiene datos de acceso, cuenta, API keys ni recursos protegidos de terceros.


## Tablero inspirado en el diseño suministrado
Diseño nativo adaptable: velocímetro iluminado, cuatro tarjetas, barra de autonomía estimada, estado GPS y botón de trayecto en vertical/horizontal. Son cambios visuales y de distribución; la lógica de GPS y baterías permanece. Modo Focus sin navegación secundaria.
