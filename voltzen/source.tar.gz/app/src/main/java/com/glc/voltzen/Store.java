package com.glc.voltzen;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Persistencia exclusivamente local y matemática de autonomía, sin dependencias externas. */
public final class Store {
    private Store() {}
    public static final String PREFS = "voltzen_v1";
    public static SharedPreferences prefs(Context c) { return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static double clamp(double v,double min,double max) { return Math.max(min,Math.min(max,v)); }
    public static double num(String s,double def,double lo,double hi) {
        try {return clamp(Double.parseDouble(s.trim().replace(',','.')),lo,hi);} catch(Exception ex){return def;}
    }
    public static String fmt(double n,int decimals) {return String.format(Locale.getDefault(),"%."+decimals+"f",n);}

    public static class Config {
        public double riderKg=110,bikeKg=34,accessoryKg=6;
        public int batteryCount=2;
        public boolean sameBattery=true;
        public double v1=48,ah1=20,v2=48,ah2=20;
        public double start1=100,start2=100;
        public double reserve=12,health=95,speedMph=16;
        public String tire="fat",terrain="mixed",assist="normal",wind="light";
        public boolean mph=true,dark=true,keepAwake=true;
        public float textScale=1.0f;
        public double gpsAccuracy=25;
        public int darkBg=Color.rgb(6,10,16),darkText=Color.WHITE,darkAccent=Color.rgb(22,226,241);
        public int lightBg=Color.rgb(247,250,253),lightText=Color.rgb(12,20,28),lightAccent=Color.rgb(0,140,165);
        public double learningRatio=1.0,learningMiles=0;
        public int learningRides=0;
        public JSONObject toJson(){
            JSONObject j=new JSONObject();try {
                j.put("riderKg",riderKg);j.put("bikeKg",bikeKg);j.put("accessoryKg",accessoryKg);
                j.put("batteryCount",batteryCount);j.put("sameBattery",sameBattery);
                j.put("v1",v1);j.put("ah1",ah1);j.put("v2",v2);j.put("ah2",ah2);
                j.put("start1",start1);j.put("start2",start2);j.put("reserve",reserve);j.put("health",health);
                j.put("speedMph",speedMph);j.put("tire",tire);j.put("terrain",terrain);j.put("assist",assist);j.put("wind",wind);
                j.put("mph",mph);j.put("dark",dark);j.put("keepAwake",keepAwake);j.put("textScale",textScale);
                j.put("gpsAccuracy",gpsAccuracy);j.put("darkBg",darkBg);j.put("darkText",darkText);j.put("darkAccent",darkAccent);
                j.put("lightBg",lightBg);j.put("lightText",lightText);j.put("lightAccent",lightAccent);
                j.put("learningRatio",learningRatio);j.put("learningMiles",learningMiles);j.put("learningRides",learningRides);
            }catch(Exception ignored){}return j;
        }
        public static Config fromJson(JSONObject j){Config c=new Config();if(j==null)return c;
            c.riderKg=j.optDouble("riderKg",c.riderKg);c.bikeKg=j.optDouble("bikeKg",c.bikeKg);
            c.accessoryKg=j.optDouble("accessoryKg",c.accessoryKg);c.batteryCount=j.optInt("batteryCount",c.batteryCount);
            c.sameBattery=j.optBoolean("sameBattery",c.sameBattery);
            c.v1=j.optDouble("v1",c.v1);c.ah1=j.optDouble("ah1",c.ah1);
            c.v2=j.optDouble("v2",c.v2);c.ah2=j.optDouble("ah2",c.ah2);
            c.start1=j.optDouble("start1",c.start1);c.start2=j.optDouble("start2",c.start2);
            c.reserve=j.optDouble("reserve",c.reserve);c.health=j.optDouble("health",c.health);
            c.speedMph=j.optDouble("speedMph",c.speedMph);
            c.tire=j.optString("tire",c.tire);c.terrain=j.optString("terrain",c.terrain);
            c.assist=j.optString("assist",c.assist);c.wind=j.optString("wind",c.wind);
            c.mph=j.optBoolean("mph",c.mph);c.dark=j.optBoolean("dark",c.dark);
            c.keepAwake=j.optBoolean("keepAwake",c.keepAwake);
            c.textScale=(float)j.optDouble("textScale",c.textScale);c.gpsAccuracy=j.optDouble("gpsAccuracy",c.gpsAccuracy);
            c.darkBg=j.optInt("darkBg",c.darkBg);c.darkText=j.optInt("darkText",c.darkText);c.darkAccent=j.optInt("darkAccent",c.darkAccent);
            c.lightBg=j.optInt("lightBg",c.lightBg);c.lightText=j.optInt("lightText",c.lightText);c.lightAccent=j.optInt("lightAccent",c.lightAccent);
            c.learningRatio=j.optDouble("learningRatio",c.learningRatio);c.learningMiles=j.optDouble("learningMiles",c.learningMiles);
            c.learningRides=j.optInt("learningRides",c.learningRides);return c;
        }
        public int bg(){return dark?darkBg:lightBg;}
        public int fg(){return dark?darkText:lightText;}
        public int cyan(){return dark?darkAccent:lightAccent;}
        public int panel(){return blend(bg(),fg(),dark?0.07f:0.045f);}
        public int muted(){return blend(bg(),fg(),0.59f);}
        public double battery2Wh(){return (sameBattery?v1*ah1:v2*ah2);}
        public double totalWh(){return v1*ah1+(batteryCount==2?battery2Wh():0);}
        public double usableWh(double s1,double s2){
            double a=v1*ah1*Math.max(0,s1/100-reserve/100);
            double b=batteryCount==2?battery2Wh()*Math.max(0,s2/100-reserve/100):0;
            return (a+b)*health/100;
        }
        public double physicalWhMile(double mphSpeed){
            double speed=clamp(mphSpeed,3,45);
            double ms=speed*0.44704;
            double mass=riderKg+bikeKg+accessoryKg;
            double crr=tire.equals("fat")?0.017:(tire.equals("mtb")?0.012:0.0075);
            double windMs=wind.equals("strong")?5.0:(wind.equals("light")?2.0:0.0);
            double grade=terrain.equals("hills")?0.012:(terrain.equals("mixed")?0.0045:0);
            double roll=mass*9.81*crr*ms;
            double aero=0.5*1.225*0.65*Math.pow(ms+windMs,2)*ms;
            double climb=mass*9.81*grade*ms;
            double motorShare=assist.equals("eco")?0.48:(assist.equals("turbo")?0.87:0.69);
            double electrical=(roll+aero+climb)*motorShare/0.81+9;
            return clamp(electrical/speed,3,150);
        }
        public double whPerMile(double speed){return physicalWhMile(speed)*clamp(learningRatio,0.4,2.5);}
        public double rangeMiles(double s1,double s2,double speed){return usableWh(s1,s2)/whPerMile(speed);}
        public String confidence(){return learningRides>=4&&learningMiles>=70?"ALTA":(learningRides>=2&&learningMiles>=20?"MEDIA":"INICIAL");}
    }
    public static int blend(int a,int b,float t){
        return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t),
                (int)(Color.green(a)*(1-t)+Color.green(b)*t),(int)(Color.blue(a)*(1-t)+Color.blue(b)*t));
    }
    public static Config config(Context c){try {return Config.fromJson(new JSONObject(prefs(c).getString("config","{}")));}catch(Exception e){return new Config();}}
    public static void save(Context c,Config x){prefs(c).edit().putString("config",x.toJson().toString()).apply();}
    public static List<JSONObject> trips(Context c){List<JSONObject> out=new ArrayList<>();try{
        JSONArray a=new JSONArray(prefs(c).getString("trips","[]"));for(int i=0;i<a.length();i++)out.add(a.getJSONObject(i));
    }catch(Exception ignored){}return out;}
    public static void addTrip(Context c,JSONObject trip){List<JSONObject> list=trips(c);list.add(0,trip);JSONArray a=new JSONArray();
        for(int i=0;i<Math.min(200,list.size());i++)a.put(list.get(i));prefs(c).edit().putString("trips",a.toString()).apply();}
    public static void clearTrips(Context c){prefs(c).edit().remove("trips").apply();}
    public static String duration(long millis){long seconds=Math.max(0,millis)/1000;return String.format(Locale.getDefault(),"%02d:%02d:%02d",seconds/3600,(seconds/60)%60,seconds%60);}
    /** Aprendizaje SOLO con porcentajes finalizados que el usuario verificó. */
    public static boolean learn(Context context,Config atStart,double distanceMiles,long movingMs,double s1,double s2,double e1,double e2){
        if(distanceMiles<2.0||movingMs<180_000||e1<0||e1>100||s1<e1)return false;
        if(atStart.batteryCount==2&&(e2<0||e2>100||s2<e2))return false;
        double consumed=(s1-e1)/100*atStart.v1*atStart.ah1;
        if(atStart.batteryCount==2)consumed+=(s2-e2)/100*atStart.battery2Wh();
        if(consumed<Math.max(25,atStart.totalWh()*0.035))return false;
        double observedMph=distanceMiles/(movingMs/3_600_000.0);
        if(observedMph<3||observedMph>50)return false;
        double baseWh=atStart.physicalWhMile(observedMph);
        double ratio=clamp(consumed/distanceMiles/baseWh,0.4,2.5);
        Config current=config(context);
        double newWeight=Math.min(30,distanceMiles);
        double priorWeight=Math.min(140,current.learningMiles)+12;
        current.learningRatio=clamp((current.learningRatio*priorWeight+ratio*newWeight)/(priorWeight+newWeight),0.4,2.5);
        current.learningMiles+=distanceMiles;
        current.learningRides++;
        save(context,current);return true;
    }
}
