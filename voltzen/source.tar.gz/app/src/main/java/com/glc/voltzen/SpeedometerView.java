package com.glc.voltzen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Dial grande, deliberadamente legible a distancia y con vibraciones. */
public class SpeedometerView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private double speed=0,max=40;
    private String unit="MPH";
    private int background=0xff070b10,text=0xffffffff,accent=0xff18e2ef,muted=0xff8a9ba7;
    private float scale=1.0f;
    public SpeedometerView(Context c){super(c);setMinimumHeight(dp(230));}
    public void update(double newSpeed,boolean useMph,Store.Config cfg){
        speed=Math.max(0,newSpeed);max=useMph?40:65;unit=useMph?"MPH":"KM/H";
        background=cfg.bg();text=cfg.fg();accent=cfg.cyan();muted=cfg.muted();scale=cfg.textScale;invalidate();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws);setMeasuredDimension(w,Math.min(dp(335),Math.max(dp(235),(int)(w*.82f))));}
    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);
        float w=getWidth(),h=getHeight(),cx=w/2,cy=h*.48f;
        float radius=Math.min(w*.35f,h*.43f);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(dp(16));paint.setColor(Store.blend(background,text,.095f));
        RectF arc=new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
        canvas.drawArc(arc,140,260,false,paint);
        paint.setColor(accent);paint.setStrokeWidth(dp(16));
        canvas.drawArc(arc,140,(float)(260*Math.min(1,speed/max)),false,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);paint.setTypeface(android.graphics.Typeface.create("sans-serif-light",0));
        paint.setColor(text);paint.setTextSize(Math.min(dp(91)*scale,radius*.92f));
        canvas.drawText(Store.fmt(speed,0),cx,cy+dp(21)*scale,paint);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium",0));paint.setColor(accent);
        paint.setTextSize(dp(16)*scale);canvas.drawText(unit,cx,cy+dp(54)*scale,paint);
        paint.setColor(muted);paint.setTextSize(dp(11)*scale);
        canvas.drawText("GPS · VELOCIDAD REAL",cx,Math.min(h-dp(12),cy+radius+dp(36)),paint);
    }
}
